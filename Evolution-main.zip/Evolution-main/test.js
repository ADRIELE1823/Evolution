<script>
  document.getElementById("circle").addEventListener("click", function() {
    window.location.href = "blog.html"// Substitua com a URL desejada
  });
</script>
